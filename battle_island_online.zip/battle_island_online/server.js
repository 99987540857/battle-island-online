const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = process.env.PORT || 10000;
const publicDir = path.join(__dirname, "public");
const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
  const requested = urlPath === "/" ? "/index.html" : urlPath;
  const file = path.normalize(path.join(publicDir, requested));
  if (!file.startsWith(publicDir)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const types = { ".html":"text/html; charset=utf-8", ".js":"text/javascript", ".css":"text/css" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
    res.end(data);
  });
});
const wss = new WebSocket.Server({ server, path: "/ws" });
const players = new Map();
const arenas = ["island", "desert", "ice", "volcano"];
const votes = {};
let currentArena = "island";

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function broadcast(obj) {
  const data = JSON.stringify(obj);
  for (const client of wss.clients) if (client.readyState === WebSocket.OPEN) client.send(data);
}
wss.on("connection", ws => {
  const id = Math.random().toString(36).slice(2, 10);
  const colors = ["#268cff", "#e34b40", "#d7a72d", "#55a45e", "#9b6bd1"];
  const player = { id, name: "Spieler-" + id.slice(0, 4), x: Math.random()*8-4, y: 0, z: Math.random()*8-4, yaw: 0, color: colors[Math.floor(Math.random()*colors.length)], hp: 100 };
  players.set(id, player);
  send(ws, { type: "welcome", id, players: [...players.values()], votes, arena: currentArena });
  broadcast({ type: "playerJoined", player });
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const p = players.get(id);
    if (!p || !msg || typeof msg.type !== "string") return;
    if (msg.type === "move") {
      p.x = clamp(msg.x, -95, 95); p.y = clamp(msg.y, 0, 5); p.z = clamp(msg.z, -95, 95);
      p.yaw = Number(msg.yaw) || 0;
      p.name = typeof msg.name === "string" ? msg.name.slice(0, 16) : p.name;
    } else if (msg.type === "vote" && arenas.includes(msg.arena)) {
      votes[id] = msg.arena;
      const counts = countVotes();
      const best = Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];
      if (best && best[1] > 0) currentArena = best[0];
      broadcast({ type: "votes", votes: counts, arena: currentArena });
    } else if (msg.type === "shoot") {
      broadcast({ type: "shot", id, x:p.x, y:p.y+1.4, z:p.z, yaw:p.yaw });
    } else if (msg.type === "hit" && typeof msg.target === "string") {
      const target = players.get(msg.target);
      if (target && target.id !== id) {
        target.hp = Math.max(0, target.hp - 25);
        broadcast({ type: "health", id: target.id, hp: target.hp, by: id });
        if (target.hp === 0) {
          target.hp = 100; target.x = Math.random()*10-5; target.z = Math.random()*10-5;
          broadcast({ type: "respawn", id: target.id, x:target.x, z:target.z });
        }
      }
    }
  });
  ws.on("close", () => {
    players.delete(id); delete votes[id];
    broadcast({ type: "playerLeft", id, votes: countVotes() });
  });
});
function countVotes() {
  const result = Object.fromEntries(arenas.map(a => [a, 0]));
  for (const v of Object.values(votes)) if (result[v] !== undefined) result[v]++;
  return result;
}
function clamp(n, min, max) { n = Number(n); return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : 0; }
setInterval(() => broadcast({ type: "state", players: [...players.values()], votes: countVotes(), arena: currentArena }), 80);
server.listen(PORT, "0.0.0.0", () => console.log("Battle Island online on port " + PORT));
