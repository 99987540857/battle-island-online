# BATTLE ISLAND ONLINE

## Was ist enthalten?
- Browser-3D-Spiel mit gemeinsamem Raum
- Spielerpositionen werden live synchronisiert
- Arena-Abstimmung
- Schießen und Treffer/Respawn-Prototyp
- WebSocket-Server

## Kostenlos online stellen (Render + GitHub)
1. Erstelle ein Konto bei GitHub und ein neues leeres Repository namens `battle-island-online`.
2. Entpacke diese ZIP-Datei auf deinem Computer.
3. Lade die Dateien und den Ordner `public` in das GitHub-Repository hoch (nicht die ZIP-Datei selbst).
4. Öffne https://render.com/ und melde dich an.
5. Wähle **New + → Web Service**, verbinde GitHub und wähle `battle-island-online`.
6. Setze **Build Command** auf `npm install` und **Start Command** auf `npm start`.
7. Wähle **Free** und klicke **Create Web Service**.
8. Wenn Render fertig ist, öffne die `onrender.com`-Adresse. Teile diesen Link mit Freunden.

## Wichtig
- Render Free kann nach 15 Minuten ohne Verkehr einschlafen; der erste Aufruf danach kann etwa eine Minute dauern.
- Dies ist ein Multiplayer-Prototyp. Spielerbewegungen, Arena-Abstimmung und einfache Treffer werden synchronisiert. Für ein großes, kompetitives Battle-Royale braucht es noch serverseitige Spielphysik, Anti-Cheat, Matchmaking und bessere Netzwerksicherheit.
- Die Anwendung verwendet Three.js von einem CDN; zum Spielen ist Internet nötig.
